package Client_Java.controller;

import Client_Java.Client;
import Client_Java.model.CountdownModel;
import Client_Java.model.LobbyModel;
import Client_Java.view.CountdownView;
import Client_Java.view.LobbyView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.io.IOException;

/**
 * This class initializes and manages the lobby scene
 */
public class Lobby {
    /**
     * The scene object representing the lobby view
     */
    public static Scene LOBBY_SCENE;

    private LobbyModel model;
    private LobbyView view;

    /**
     * Constructs a new Lobby instance with the specified model and view
     *
     * @param model The model containing the lobby data and functionality
     * @param view  The view responsible for rendering the lobby interface
     */
    public Lobby(LobbyModel model, LobbyView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Initializes the lobby scene by loading the corresponding FXML file and setting up event handlers
     */
    public void init() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/LobbyView.fxml"));

            LOBBY_SCENE = new Scene(loader.load());

            view = loader.getController();

            setUpLogoutBT();
            setUpLeaderboardsPanel();
            setUpPlayBT();
            setUpExitApp();
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end of init

    /**
     * Switches the current scene to the lobby scene
     */
    public void switchScene() {
        Client.MAIN_STAGE.setScene(LOBBY_SCENE);
    } // end of switchScene

    /**
     * Sets up the event handler for the logout button
     * Upon clicking the logout button, the user is directed back to the login scene
     * Additionally, the model's logout method is invoked
     */
    private void setUpLogoutBT() {
        view.getLogoutBT().setOnAction(event -> {
            Client.MAIN_STAGE.setScene(Login.LOGIN_SCENE);
            model.logout();
        });
    } // end of setUpExitBoggled

    /**
     * Sets up the leaderboards panel by displaying the current leaderboard data
     * The leaderboard data is refreshed when the refresh button is clicked
     */
    private void setUpLeaderboardsPanel() {
        view.showLeaderboards(model.getLeaderboard());

        view.getLeaderboardPanelRefreshBT().setOnAction(event -> {
            view.showLeaderboards(model.getLeaderboard());
        });
    } // end of setUpLeaderboardsBT

    /**
     * Sets up the event handler for the play button
     * Upon clicking the play button, the user is directed to the countdown scene to start a game session
     */
    private void setUpPlayBT() {
        view.getPlayBT().setOnAction(event -> {
            int gsID = model.playGame();
            Countdown countdown = new Countdown(new CountdownModel(model.getPlayerID(), gsID), new CountdownView());
            countdown.init();
        });
    } // end of setUpPlayBT

    /**
     * Sets up the exit
     * When the application window is closed, the user is logged out and the application terminates
     */
    private void setUpExitApp() {
        Client.MAIN_STAGE.setOnCloseRequest(windowEvent -> {
            model.logout();
            System.exit(0);
        });
    } // end of setUpExitApp
} // end of Lobby class