package Client_Java.controller;

import BoggledApp.GameTimeout;
import BoggledApp.InvalidWord;
import Client_Java.Client;
import Client_Java.controller.popups.GameWinnerPopup;
import Client_Java.controller.popups.LosePopup;
import Client_Java.controller.popups.RoundPopup;
import Client_Java.controller.popups.RoundWinnerPopup;
import Client_Java.model.GameModel;
import Client_Java.view.GameView;
import Client_Java.view.popups.RoundPopupView;
import Client_Java.view.popups.RoundWinnerPopupView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Manages the game session, including updating game data, displaying popups, and handling user input
 */
public class Game {
    private final GameModel model;
    private GameView view;
    private final RoundPopup roundPopup;
    private final RoundWinnerPopup roundWinnerPopup;
    private final LosePopup losePopup;
    private final GameWinnerPopup gameWinnerPopup;
    private int currentRoundTime;

    /**
     * Constructs a new Game instance with the specified model and view
     * Initializes popup objects and their corresponding views
     *
     * @param model The model containing game data and functionality
     * @param view  The view responsible for rendering the game interface
     */
    public Game(GameModel model, GameView view) {
        this.model = model;
        this.view = view;

        roundPopup = new RoundPopup();
        roundWinnerPopup = new RoundWinnerPopup();
        losePopup = new LosePopup();
        gameWinnerPopup = new GameWinnerPopup();

        roundPopup.init();
        roundWinnerPopup.init();
        losePopup.init();
        gameWinnerPopup.init();
    }

    /**
     * Initializes the game session by loading the game view and setting up event handlers
     */
    public void init() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/GameView.fxml"));

            Scene scene = new Scene(loader.load());

            view = loader.getController();

            view.getPlayerLB().setText(model.getUsername());

            Client.MAIN_STAGE.setScene(scene);

            setUpWordInputFunc();
            setUpExitApp();
        } catch (IOException e) {
            e.printStackTrace();
        }

        startGame();
    } // end of init

    /**
     * One time invocation to handle the game session
     */
    private void startGame() {
        Thread game = new Thread(() -> {
            while (true) {
                if (!model.getGameWinner().equals("None")) {
                    finalizeGame();
                    Platform.runLater(() -> Client.MAIN_STAGE.setScene(Lobby.LOBBY_SCENE));
                    break;
                }

                if (!model.getRoundWinner().equals("None")) {
                    if (model.getRoundWinner().equals(model.getUsername())) {
//                        showRoundWinnerPopup(false);
                    } else {
//                        showRoundWinnerPopup(true);
                    }
                    delay(4000);
                }

                model.getGameRound();

                updateData();

                showRoundPopup();

                startCountdown();

                while (true) {
                    if (model.roundEvaluationDone()) {
                        break;
                    }
                }
            }
        });
        game.setDaemon(true);
        game.start();
    } // end of startGame

    /**
     * Starts the countdown timer for the current round, allowing players to input words within the time limit
     */
    private void startCountdown() {
        view.getWordsField().clear();
        view.getWordsField().setDisable(false);

        while (true) {
            try {
                currentRoundTime = model.getCurrentRoundTime();

                Platform.runLater(() -> view.getTimerLabel().setText(String.valueOf(currentRoundTime)));

                Thread.sleep(100);
            } catch (GameTimeout gameTimeout) {
                view.getWordsField().setDisable(true);
                break;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    } // end of startCountdown

    /**
     * Sets up the event handler for word input by the player
     * Words entered by the player are validated and added to the game model
     */
    private void setUpWordInputFunc() {
        view.getWordsField().setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ENTER) {
                String word = view.getWordsField().getText().trim().toLowerCase();

                try {
                    if (!word.isEmpty()) {
                        if (model.isAlreadyInTheEntry(word)) {
                            setNoticeMessage(word + " is already in the word entries");
                        } else {
                            model.sendWord(word);
                            view.addWord(word);
                        }
                    }
                } catch (InvalidWord e) {
                    setNoticeMessage(word + " is invalid");
                } finally {
                    view.getWordsField().clear();
                }
            }
        });
    } // end of setUpWordInputFunc

    /**
     * Updates the game data displayed in the UI, including game points, character set, word entries, and scoreboard
     */
    private void updateData() {
        Platform.runLater(() -> {
            view.getPointsLabel().setText(model.getGamePoints());
            view.updateCharacterSet(model.getRound().characters);
            view.getWordListPane().getChildren().clear();
            model.clearWordEntries();
            view.updateScoreboard(model.getRound().players);
        });
    } // end of updateData

    /**
     * Displays the round popup to inform players about the current round number
     */
    private void showRoundPopup() {
        delay(1000);
        roundPopup.setRoundNumber(model.getRound().currentRoundNumber);
        roundPopup.showPopup();
        new Timer(true).schedule(new TimerTask() {
            @Override
            public void run() {
                roundPopup.hidePopup();
            }
        }, 3000);
    } // end of showRoundPopup

    /**
     * Displays the game winner or loser popup based on the game outcome
     *
     * @param isWinner Boolean indicating whether the player is the winner or loser
     */
    private void showGameWinnerPopup(boolean isWinner) {
        delay(1000);

        if (isWinner) {
            gameWinnerPopup.showPopup();
        } else {
            losePopup.showPopup();
        }

        new Timer(true).schedule(new TimerTask() {
            @Override
            public void run() {
                if (isWinner) {
                    gameWinnerPopup.hidePopup();
                } else {
                    losePopup.hidePopup();
                }
            }
        }, 3000);
    } // end of showGameWinnerPopup

    /**
     * Finalizes the game session by updating the UI, displaying the game winner or loser popup,
     * and leaving the game
     */
    private void finalizeGame() {
        model.getGameRound();

        Platform.runLater(() -> {
            view.getPointsLabel().setText(model.getGamePoints());
            view.updateScoreboard(model.getRound().players);
        });

        if (model.getGameWinner().equals(model.getUsername())) {
            showGameWinnerPopup(true);
        } else {
            showGameWinnerPopup(false);
        }

        delay(4000);
        model.leave();
    }

    /**
     * Displays a temporary notice message in the UI,
     * for the exception handling notification
     *
     * @param message The message to be displayed.
     */
    private void setNoticeMessage(String message) {
        view.getErrorLB().setText(message);

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> view.getErrorLB().setText(""));
            }
        }, 3000);
    } // end of setNoticeMessage

    /**
     * Sets up the action to be taken when the application window is closed,
     * ensuring that the player leaves the game before exiting
     */
    private void setUpExitApp() {
        Client.MAIN_STAGE.setOnCloseRequest(windowEvent -> {
            model.leave();
            System.exit(0);
        });
    }

    /**
     * Delays the execution for a specified number of milliseconds
     *
     * @param millis The duration of the delay in milliseconds
     */
    private void delay(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    } // end of delay
} // end of Game class