package Client_Java.controller;

import BoggledApp.GameTimeout;
import Client_Java.Client;
import Client_Java.model.CountdownModel;
import Client_Java.model.GameModel;
import Client_Java.view.CountdownView;
import Client_Java.view.GameView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This class handles the countdown view and functionality before the start of the game
 */
public class Countdown {
    private final CountdownModel model;
    private CountdownView view;
    private int secondsLeft;
    private int numberOfPlayers;

    /**
     * Constructor for the Countdown class
     *
     * @param model The model containing countdown data
     * @param view  The view for the countdown
     */
    public Countdown(CountdownModel model, CountdownView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Initializes the countdown view and starts the countdown
     */
    public void init() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/CountdownView.fxml"));

            Scene countdownScene = new Scene(loader.load());

            view = loader.getController();

            Client.MAIN_STAGE.setScene(countdownScene);

            setUpBackButton();
            startCountdown();
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end of init

    /**
     * Creates a thread to continuously obtain the current time of the countdown
     */
    private void startCountdown() {
        Thread countdown = new Thread(() -> {
            try {
                while (true) {
                    secondsLeft = model.getRemainingWaitingTime();
                    numberOfPlayers = model.getNumberOfWaitingPlayers();

                    Platform.runLater(() -> view.getCountdownLB().setText(String.valueOf(secondsLeft)));

                    Thread.sleep(100);
                }
            } catch (GameTimeout gameTimeout) {
                handleSequence();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        countdown.setDaemon(true);
        countdown.start();
    } // end of startCountdown

    /**
     * Handles the sequence after the countdown ends
     * If there are more than 1 player, starts the game. Otherwise, returns to the lobby.
     */
    private void handleSequence() {
        Timer delay = new Timer();
        delay.schedule(new TimerTask() {
            @Override
            public void run() {
                if (numberOfPlayers > 1) {
                    Platform.runLater(() -> {
                        Game game = new Game(new GameModel(model.getPlayerID(), model.getGsID()), new GameView());
                        game.init();
                    });
                } else {
                    Platform.runLater(() -> Client.MAIN_STAGE.setScene(Lobby.LOBBY_SCENE));
                }
            }
        }, 1000);
    } // end of handleSequence

    /**
     * Sets up the functionality for the back button
     * When clicked, leaves the countdown and returns to the lobby
     */
    private void setUpBackButton() {
        view.getBackBT().setOnAction(event -> {
            model.leave();
            Client.MAIN_STAGE.setScene(Lobby.LOBBY_SCENE);
        });
    } // end of setUpBackButton
} // end of Countdown class
