package Client_Java.controller;

import BoggledApp.AlreadyLoggedIn;
import BoggledApp.DoesNotExist;
import Client_Java.Client;
import Client_Java.model.LobbyModel;
import Client_Java.model.LoginModel;
import Client_Java.view.LobbyView;
import Client_Java.view.LoginView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This class initializes and manages the login scene
 */
public class Login {
    /**
     * The scene object representing the login view
     */
    public static Scene LOGIN_SCENE;

    private final LoginModel model;
    private LoginView view;
    private final Lobby lobby;
    private final LobbyModel lobbyModel;

    private Timer timer = new Timer();

    /**
     * Constructs a new Login instance with the specified model and view
     * Initializes the lobby model and lobby view
     *
     * @param model The model containing the login data and functionality
     * @param view  The view responsible for rendering the login interface
     */
    public Login(LoginModel model, LoginView view) {
        this.model = model;
        this.view = view;

        lobbyModel = new LobbyModel();
        lobby = new Lobby(lobbyModel, new LobbyView());
        lobby.init();
    }

    /**
     * Initializes the login scene by loading the corresponding FXML file and setting up event handlers
     */
    public void init() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/LoginView.fxml"));

            LOGIN_SCENE = new Scene(loader.load());

            view = loader.getController();

            Client.MAIN_STAGE.setScene(LOGIN_SCENE);

            setUpLoginBT();
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end of init

    /**
     * Sets up the event handler for the login button
     *
     * Upon clicking the login button, the user's credentials are verified and, if valid,
     * the user is directed to the lobby scene
     *
     * If the login attempt fails due to invalid credentials or a user already being logged in,
     * an appropriate notice is displayed
     */
    private void setUpLoginBT() {
        view.getLoginBT().setOnAction(event -> {
            try {
                int playerID = model.login(view.getUsernameTF().getText(), view.getPasswordTF().getText());

                lobbyModel.setPlayerID(playerID);
                lobby.switchScene();
            } catch (AlreadyLoggedIn e1) {
                setNoticeText("Account is already logged in");
            } catch (DoesNotExist e2) {
                setNoticeText("Invalid credentials");
            }
        });
    } // end of setUpLoginBT

    /**
     * Sets the text of the notice label and schedules its disappearance after a certain delay
     *
     * @param text The text to be displayed in the notice label
     */
    private void setNoticeText(String text) {
        timer.cancel();

        view.getNoticeLB().setText(text);

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                view.getNoticeLB().setText("");
            }
        }, 5000);
    } // end of setNoticeText
} // end of Login class
