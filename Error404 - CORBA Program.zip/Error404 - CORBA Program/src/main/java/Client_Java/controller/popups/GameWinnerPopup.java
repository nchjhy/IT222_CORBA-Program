package Client_Java.controller.popups;

import Client_Java.view.popups.GameWinnerPopupView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.io.IOException;

/**
 * This class represents a popup that displays the game winner
 */
public class GameWinnerPopup {
    private GameWinnerPopupView view;
    private Stage popupStage;

    /**
     * Constructor for GameWinnerPopup
     */
    public GameWinnerPopup() {}

    /**
     * Initializes the game winner popup
     * This method sets up the popup stage, loads the FXML layout, and configures the popup properties
     */
    public void init() {
        try {
            popupStage = new Stage();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/GameWinnerView.fxml"));

            Scene scene = new Scene(loader.load());

            view = loader.getController();

            popupStage.setFullScreen(false);
            popupStage.initStyle(StageStyle.UNDECORATED);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setScene(scene);
        } catch (RuntimeException | IOException e) {
            e.printStackTrace();
        }
    } // end of init

    /**
     * Displays the game winner popup
     * This method ensures that the popup is shown on the JavaFX Application Thread
     */
    public void showPopup() {
        Platform.runLater(() -> popupStage.show());
    } // end of showPopup

    /**
     * Hides the game winner popup.
     * This method ensures that the popup is hidden on the JavaFX Application Thread
     */
    public void hidePopup() {
        Platform.runLater(() -> popupStage.hide());
    } // end of hidePopup

} // end of GameWinnerPopup class
