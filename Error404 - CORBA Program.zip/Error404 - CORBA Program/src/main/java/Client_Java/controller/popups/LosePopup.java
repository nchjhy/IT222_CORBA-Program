package Client_Java.controller.popups;

import Client_Java.view.popups.LosePopupView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.io.IOException;

/**
 * This class represents a popup that notifies the user of losing the game
 */
public class LosePopup {
    private LosePopupView view;
    private Stage popupStage;

    /**
     * Constructor for LosePopup
     */
    public LosePopup() {}

    /**
     * Initializes the lose popup
     * This method sets up the popup stage, loads the FXML layout, and configures the popup properties
     */
    public void init() {
        try {
            popupStage = new Stage();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/client/LoseView.fxml"));

            Scene scene = new Scene(loader.load());

            view = loader.getController();

            popupStage.setFullScreen(false);
            popupStage.initStyle(StageStyle.UNDECORATED);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // end of init

    /**
     * Displays the lose popup
     * This method ensures that the popup is shown on the JavaFX Application Thread
     */
    public void showPopup() {
        Platform.runLater(() -> popupStage.show());
    } // end of showPopup

    /**
     * Hides the lose popup
     * This method ensures that the popup is hidden on the JavaFX Application Thread
     */
    public void hidePopup() {
        Platform.runLater(() -> popupStage.hide());
    } // end of hidePopup

} // end of LosePopup class
