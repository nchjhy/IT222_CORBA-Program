package Client_Java.controller.cards;

import Client_Java.view.cards.ScoreboardCardView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import java.io.IOException;

/**
 * This class represents a scoreboard card
 */
public class ScoreboardCard {

    /**
     * Constructor for ScoreboardCard
     */
    public ScoreboardCard() {}

    /**
     * Creates a scoreboard card Node for a given user.
     *
     * @param username A string containing the username to be displayed on the card
     * @param winCount A string containing the win count to be displayed on the card
     * @return A Node representing the scoreboard card, or null if an error occurs during loading
     */
    public static Node createCard(String username, String winCount) {
        try {
            FXMLLoader loader = new FXMLLoader(ScoreboardCard.class.getResource("/fxml/client/ScoreboardCard.fxml"));

            Node card = loader.load();

            ScoreboardCardView view = loader.getController();

            view.getUsernameLB().setText(username);
            view.getWinsLB().setText(winCount);

            return card;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    } // end of createCard
} // end of ScoreboardCard class
