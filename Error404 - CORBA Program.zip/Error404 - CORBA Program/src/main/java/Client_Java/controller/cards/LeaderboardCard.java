package Client_Java.controller.cards;

import Client_Java.view.cards.LeaderboardCardView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import java.io.IOException;

/**
 * This class represents a leaderboard card
 */
public class LeaderboardCard {

    /**
     *  Constructor for LeaderboardCard
     */
    public LeaderboardCard() {}

    /**
     * Creates a leaderboard card Node for a given player
     *
     * @param player A string containing the player's name and points, separated by a hyphen (e.g., "nichs-100")
     * @return A Node representing the leaderboard card, or null if an error occurs during loading.
     */
    public static Node createCard(String player) {
        try {
            FXMLLoader loader = new FXMLLoader(LeaderboardCard.class.getResource("/fxml/client/LeaderboardCard.fxml"));

            Node card = loader.load();

            LeaderboardCardView view = loader.getController();

            String playerName = player.split("-")[0];
            String points = player.split("-")[1];

            view.getUsernameLB().setText(playerName);
            view.getPointsLB().setText(points);

            return card;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    } // end of createCard
} // end of LeaderboardCard class
