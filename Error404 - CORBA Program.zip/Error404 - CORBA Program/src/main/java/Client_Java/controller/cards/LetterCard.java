package Client_Java.controller.cards;

import Client_Java.view.cards.LetterCardView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import java.io.IOException;

/**
 * This class represents a letter card
 */
public class LetterCard {

    /**
     *  Constructor for LetterCard
     */
    public LetterCard() {}

    /**
     * Creates a letter card Node for a given letter
     *
     * @param letter A char representing the letter to be displayed on the card
     * @return A Node representing the letter card, or null if an error occurs during loading
     */
    public static Node createCard(char letter) {
        try {
            FXMLLoader loader = new FXMLLoader(LetterCard.class.getResource("/fxml/client/LetterCard.fxml"));

            Node card = loader.load();

            LetterCardView view = loader.getController();

            view.getCharacterLB().setText(String.valueOf(letter));

            return card;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    } // end of createCard
} // end of LetterCard class
