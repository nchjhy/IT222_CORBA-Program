package Client_Java.controller.cards;

import Client_Java.view.cards.WordListCardView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import java.io.IOException;

/**
 * This class represents a word list card
 */
public class WordListCard {

    /**
     * Constructor for WordListCard
     */
    public WordListCard() {}

    /**
     * Creates a word list card Node for a given word
     *
     * @param word A string containing the word to be displayed on the card
     * @return A Node representing the word list card, or null if an error occurs during loading
     */
    public static Node createCard(String word) {
        try {
            FXMLLoader loader = new FXMLLoader(WordListCard.class.getResource("/fxml/client/WordListCard.fxml"));

            Node card = loader.load();

            WordListCardView view = loader.getController();

            view.getWordLB().setText(word);

            return card;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    } // end of createCard
} // end of WordListCard class
