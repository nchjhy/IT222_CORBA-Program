package Client_Java.view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * The LoginView class manages the UI components for the login screen
 */
public class LoginView {

    @FXML
    private TextField usernameTF, passwordTF;

    @FXML
    private Button loginBT;

    @FXML
    private Text noticeLB;

    /**
     * Constructs a LoginView object
     */
    public LoginView() {}

    // Getter methods for accessing UI components

    public TextField getUsernameTF() {
        return usernameTF;
    }

    public TextField getPasswordTF() {
        return passwordTF;
    }

    public Button getLoginBT() {
        return loginBT;
    }

    public Text getNoticeLB() {
        return noticeLB;
    }
} // end of LoginView class
