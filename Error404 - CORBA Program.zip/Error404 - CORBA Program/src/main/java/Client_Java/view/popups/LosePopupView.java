package Client_Java.view.popups;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

/**
 * The LosePopupView class represents the view for the lose popup
 */
public class LosePopupView {

    @FXML
    private Text youLose;  // Text for the "You Lose" message
    @FXML
    private Text loseMessage;  // Text for displaying lose message

    /**
     * Constructs a LosePopupView object
     */
    public LosePopupView() {}

    public Text getYouLose() {
        return youLose;
    }

    public Text getLoseMessage() {
        return loseMessage;
    }

} // end of LosePopupView class
