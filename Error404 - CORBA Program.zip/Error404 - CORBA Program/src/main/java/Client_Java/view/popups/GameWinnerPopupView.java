package Client_Java.view.popups;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

/**
 * The GameWinnerPopupView class represents the view for the game winner popup
 */
public class GameWinnerPopupView {

    @FXML
    private Text hurray;  // Text for the "HURRAY!" message
    @FXML
    private Text winMessage;  // Text for displaying win message

    /**
     * Constructs a GameWinnerPopupView object
     */
    public GameWinnerPopupView() {}


    public Text getHurray() {
        return hurray;
    }

    public Text getWinMessage() {
        return winMessage;
    }

} // end of GameWinnerPopupView class
