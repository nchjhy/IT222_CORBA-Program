package Client_Java.view.popups;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.text.Text;

/**
 * The RoundWinnerPopupView class represents the view for the round winner popup
 */
public class RoundWinnerPopupView {

    @FXML
    private Label roundWinnerLB;  // Label for displaying the round winner
    @FXML
    private Text hurray;  // Text element for a congratulatory message

    /**
     * Constructs a RoundWinnerPopupView object
     */
    public RoundWinnerPopupView() {}

    public Label getRoundWinnerLB() {
        return roundWinnerLB;
    }

    public Text getHurray() {
        return hurray;
    }

} // end of RoundWinnerPopupView class
