package Client_Java.view.popups;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

/**
 * The RoundPopupView class represents the view for the round popup
 */
public class RoundPopupView {

    @FXML
    private Text roundNumberLB;  // Text element for displaying the round number

    /**
     * Constructs a RoundPopupView object
     */
    public RoundPopupView() {}

    public Text getRoundNumberLB() {
        return roundNumberLB;
    }

} // end of RoundPopupView class
