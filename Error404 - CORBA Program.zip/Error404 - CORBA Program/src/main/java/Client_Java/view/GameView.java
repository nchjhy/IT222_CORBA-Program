package Client_Java.view;

import Client_Java.controller.cards.LetterCard;
import Client_Java.controller.cards.ScoreboardCard;
import Client_Java.controller.cards.WordListCard;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import java.util.ArrayList;
import java.util.List;

/**
 * The GameView class manages the UI components for the game screen
 */
public class GameView {

    @FXML
    private Label playerLB, timerLabel, pointsLabel, errorLB;

    @FXML
    private TextField wordsField;

    @FXML
    private Button submitButton, clearButton;

    @FXML
    private FlowPane characterSetPane, wordListPane, scoreboardPane;

    /**
     * Constructs a GameView object
     */
    public GameView() {}

    /**
     * Initializes the controller class
     * This method is automatically called after the fxml file has been loaded
     */
    @FXML
    public void initialize() {
        clearButton.setOnAction(event -> {
            wordsField.clear();
        });
    } // end of initialize

    /**
     * Updates the character set displayed on the game screen
     *
     * @param characters the characters to be displayed
     */
    public void updateCharacterSet(String characters) {
        List<Node> letterCards = new ArrayList<>();

        for (char letter : characters.toUpperCase().toCharArray()) {
            letterCards.add(LetterCard.createCard(letter));
        }

        characterSetPane.getChildren().clear();
        characterSetPane.getChildren().addAll(letterCards);
    } // end of updateCharacterSet

    /**
     * Updates the scoreboard displayed on the game screen
     *
     * @param players an array containing player information
     */
    public void updateScoreboard(String[] players) {
        List<Node> scoreboardCards = new ArrayList<>();

        for (String entry : players) {
            String username = entry.split("-")[0];
            String winCount = entry.split("-")[1];

            scoreboardCards.add(ScoreboardCard.createCard(username, winCount));
        }

        scoreboardPane.getChildren().clear();
        scoreboardPane.getChildren().addAll(scoreboardCards);
    } // end of updateScoreboard

    /**
     * Adds a word to the word list displayed on the game screen
     *
     * @param word the word to be added
     */
    public void addWord(String word) {
        wordListPane.getChildren().add(WordListCard.createCard(word));
    } // end of addWord

    // Getters for accessing UI components

    public FlowPane getWordListPane() {
        return wordListPane;
    }

    public TextField getWordsField() {
        return wordsField;
    }

    public Label getPlayerLB() {
        return playerLB;
    }

    public Label getTimerLabel() {
        return timerLabel;
    }

    public Label getPointsLabel() {
        return pointsLabel;
    }

    public Label getErrorLB() {
        return errorLB;
    }

    public Button getSubmitButton() {
        return submitButton;
    }
} // end of GameView class
