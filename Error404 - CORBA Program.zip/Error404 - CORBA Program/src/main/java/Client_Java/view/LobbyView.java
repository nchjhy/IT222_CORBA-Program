package Client_Java.view;

import Client_Java.controller.cards.LeaderboardCard;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;

import java.util.ArrayList;
import java.util.List;

/**
 * The LobbyView class manages the UI components for the lobby screen
 */
public class LobbyView {

    @FXML
    private Button logoutBT, leaderboardPanelRefreshBT, playBT;

    @FXML
    private FlowPane leaderboardPanel;

    /**
     * Constructs a LobbyView object
     */
    public LobbyView() {}

    /**
     * Displays the leaderboards on the lobby screen
     *
     * @param leaderboard a list containing leaderboard information
     */
    public void showLeaderboards(List<String> leaderboard) {
        List<Node> cards = new ArrayList<>();

        for (String row : leaderboard) {
            cards.add(LeaderboardCard.createCard(row));
        }

        leaderboardPanel.getChildren().clear();
        leaderboardPanel.getChildren().addAll(cards);
    } // end of showLeaderboards

    // Getter methods for accessing UI components

    public Button getLogoutBT() {
        return logoutBT;
    }

    public Button getPlayBT() {
        return playBT;
    }

    public Button getLeaderboardPanelRefreshBT() {
        return leaderboardPanelRefreshBT;
    }

    public FlowPane getLeaderboardPanel() {
        return leaderboardPanel;
    }
} // end of LobbyView class
