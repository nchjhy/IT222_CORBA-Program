package Client_Java.view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * The CountdownView class represents the view for the countdown screen
 * It contains a label for displaying the countdown and a button for navigating back
 */
public class CountdownView {

    @FXML
    private Label countdownLB;  // Label for displaying the countdown
    @FXML
    private Button backBT; // Button for navigating back

    /**
     * Constructs a CountdownView object
     */
    public CountdownView() {}

    public Label getCountdownLB() {
        return countdownLB;
    }

    public Button getBackBT() {
        return backBT;
    }
} // end of CountdownView class
