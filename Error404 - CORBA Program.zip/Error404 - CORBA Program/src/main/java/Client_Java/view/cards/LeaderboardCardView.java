package Client_Java.view.cards;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * The LeaderboardCardView class represents the view for a single entry in the leaderboard
 * It contains labels to display the username and the corresponding points
 */
public class LeaderboardCardView {

    @FXML
    private Label usernameLB;  // Label for displaying the username
    @FXML
    private Label pointsLB;    // Label for displaying the points

    /**
     * Constructs a LeaderboardCardView object
     */
    public LeaderboardCardView() {}


    public Label getUsernameLB() {
        return usernameLB;
    }

    public Label getPointsLB() {
        return pointsLB;
    }
} // end of LeaderboardCardView class
