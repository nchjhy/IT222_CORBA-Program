package Client_Java.view.cards;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * The WordListCardView class represents the view for a single card in a word list
 * It contains a label to display a word
 */
public class WordListCardView {

    @FXML
    private Label wordLB;  // Label for displaying the word

    /**
     * Constructs a WordListCardView object
     */
    public WordListCardView() {}

    public Label getWordLB() {
        return wordLB;
    }
} // end of WordListCardView class
