package Client_Java.view.cards;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * The LetterCardView class represents the view for a single letter card
 * It contains a label to display the character
 */
public class LetterCardView {

    @FXML
    private Label characterLB;  // Label for displaying the character

    /**
     * Constructs a LetterCardView object
     */
    public LetterCardView() {}


    public Label getCharacterLB() {
        return characterLB;
    }
} // end of LetterCardView class
