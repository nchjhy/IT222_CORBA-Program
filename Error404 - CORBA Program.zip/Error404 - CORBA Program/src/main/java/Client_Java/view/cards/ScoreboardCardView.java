package Client_Java.view.cards;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * The ScoreboardCardView class represents the view for a single scoreboard card
 * It contains labels to display the username and wins
 */
public class ScoreboardCardView {

    @FXML
    private Label usernameLB, winsLB;  // Labels for displaying username and wins

    /**
     * Constructs a ScoreboardCardView object
     */
    public ScoreboardCardView() {}


    public Label getUsernameLB() {
        return usernameLB;
    }

    public Label getWinsLB() {
        return winsLB;
    }
} // end of ScoreboardCardView class
