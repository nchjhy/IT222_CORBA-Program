package Client_Java.model;

import BoggledApp.BoggledAppServer;
import BoggledApp.BoggledAppServerHelper;
import Server_Java.model.IPAdd;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import javax.swing.*;

public class ClientModel {
    // Reference to the BoggledAppServer object to communicate with the server
    public static BoggledAppServer boggledServant;

    public ClientModel() {}

    /**
     * Establishes a connection to the server.
     * Prompts the user to input the server's IP address and initializes the ORB to connect to the server.
     */
    public void connectToServer() {
        // Prompt user to input the server's IP address
        String SERVER_ADDRESS = JOptionPane.showInputDialog(null, "Enter the IP Address of the server:", "Server IP", JOptionPane.QUESTION_MESSAGE);
        IPAdd.setServerIP(SERVER_ADDRESS);

        // ORB initialization parameters
        String[] args = {"-ORBInitialPort", "12345", "-ORBInitialHost", SERVER_ADDRESS};

        try {
            // Initialize the ORB
            ORB orb = ORB.init(args, null);

            // Get the root naming context
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

            // Use NamingContextExt instead of NamingContext. This is part
            // of the Interoperable naming Service.
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            // Resolve the Object Reference in Naming
            String name = "ServerService";
            boggledServant = BoggledAppServerHelper.narrow(ncRef.resolve_str(name));
        } catch (Exception e) {
            // Handle exceptions such as invalid IP address
            System.err.println("Invalid IP Address: " + e.getMessage());
            e.printStackTrace();
        }
    } // end of connectToServer
} // end of ClientModel class
