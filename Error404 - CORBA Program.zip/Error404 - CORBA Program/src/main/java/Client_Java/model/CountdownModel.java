package Client_Java.model;

import BoggledApp.GameTimeout;

/**
 * The CountdownModel class represents the model component for the countdown functionality in the client
 * It provides methods to interact with the server for managing countdown and game waiting times
 */
public class CountdownModel {
    private int playerID;
    private int gsID;

    /**
     * Constructs a CountdownModel object with the specified player ID and game session ID
     *
     * @param playerID The ID of the player
     * @param gsID The ID of the game session
     */
    public CountdownModel(int playerID, int gsID) {
        this.playerID = playerID;
        this.gsID = gsID;
    }

    /**
     * Sends a request to the server to leave the game session
     */
    public void leave() {
        ClientModel.boggledServant.leaveGame(playerID, gsID);
    } // end of leave

    /**
     * Retrieves the remaining waiting time for the game session
     *
     * @return The remaining waiting time in seconds
     * @throws GameTimeout If the waiting time exceeds the specified limit
     */
    public int getRemainingWaitingTime() throws GameTimeout {
        return ClientModel.boggledServant.getCurrentWaitingTime();
    } // end of getRemainingWaitingTime

    /**
     * Retrieves the number of players currently waiting in the game session
     *
     * @return The number of waiting players
     */
    public int getNumberOfWaitingPlayers() {
        return ClientModel.boggledServant.getNumberOfWaitingPlayers();
    } // end of getNumberOfWaitingPlayers

    /**
     * Gets the ID of the player associated with the countdown
     *
     * @return The player ID
     */
    public int getPlayerID() {
        return playerID;
    }

    /**
     * Gets the ID of the game session associated with the countdown
     *
     * @return The game session ID
     */
    public int getGsID() {
        return gsID;
    }
} // end of CountdownModel
