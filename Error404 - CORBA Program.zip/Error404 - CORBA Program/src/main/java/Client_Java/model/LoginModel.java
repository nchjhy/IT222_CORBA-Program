package Client_Java.model;

import BoggledApp.AlreadyLoggedIn;
import BoggledApp.DoesNotExist;

/**
 * The LoginModel class represents the model component for the login functionality in the client
 * It provides a method to log in to the server using a username and password
 */
public class LoginModel {

    /**
     * Constructs a LoginModel object
     */
    public LoginModel() {}

    /**
     * Attempts to log in the user with the provided username and password
     *
     * @param username The username of the user trying to log in
     * @param password The password of the user trying to log in
     * @return The player ID assigned by the server upon successful login
     * @throws AlreadyLoggedIn if the user is already logged in
     * @throws DoesNotExist if the user does not exist
     */
    public int login(String username, String password) throws AlreadyLoggedIn, DoesNotExist {
        return ClientModel.boggledServant.login(username, password);
    } // end of login
} // end of LoginModel class
