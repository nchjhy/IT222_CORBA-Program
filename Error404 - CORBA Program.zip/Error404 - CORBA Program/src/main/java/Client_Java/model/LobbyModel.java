package Client_Java.model;

import Client_Java.Client;
import Server_Java.database.DatabaseManager;
import java.util.Arrays;
import java.util.List;

/**
 * The LobbyModel class represents the model component for the lobby in the client
 * It provides methods to interact with the server for managing game sessions, logging out, and retrieving the leaderboard
 */
public class LobbyModel {
    private int playerID;

    /**
     * Constructs a LobbyModel object
     */
    public LobbyModel() {
    }

    /**
     * Joins a game session and returns the game session ID
     *
     * @return The ID of the game session the player joins
     */
    public int playGame() {
        return ClientModel.boggledServant.joinGameSession(playerID);
    } // end of playGame

    /**
     * Logs out the player from the server
     */
    public void logout() {
        ClientModel.boggledServant.logout(playerID);
    } // end of logout

    /**
     * Retrieves the leaderboard from the server
     *
     * @return A list of leaderboard entries
     */
    public List<String> getLeaderboard() {
        return Arrays.asList(ClientModel.boggledServant.getLeaderboard());
    } // end of getLeaderboard

    /**
     * Sets the player ID
     *
     * @param playerID The ID of the player
     */
    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    /**
     * Gets the player ID
     *
     * @return The ID of the player
     */
    public int getPlayerID() {
        return playerID;
    }
} // end of LobbyModel class
