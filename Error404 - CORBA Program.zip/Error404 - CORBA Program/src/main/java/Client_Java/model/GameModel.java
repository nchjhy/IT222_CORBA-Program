package Client_Java.model;

import BoggledApp.GameRound;
import BoggledApp.GameTimeout;
import BoggledApp.InvalidWord;
import java.util.HashSet;
import java.util.Set;

/**
 * The GameModel class represents the model component for the game session in the client
 * It provides methods to interact with the server for managing game rounds, sending words, and retrieving game state information
 */
public class GameModel {
    private int playerID;
    private int gsID;
    private String username;
    private GameRound round = new GameRound(0, null, 0, null);
    private final Set<String> wordEntry = new HashSet<>();

    /**
     * Constructs a GameModel object with the specified player ID and game session ID
     *
     * @param playerID The ID of the player
     * @param gsID The ID of the game session
     */
    public GameModel(int playerID, int gsID) {
        this.playerID = playerID;
        this.gsID = gsID;
        this.username = ClientModel.boggledServant.getUsername(playerID);
    }

    /**
     * Gets the ID of the game session
     *
     * @return The game session ID
     */
    public int getGsID() {
        return gsID;
    }

    /**
     * Retrieves the current game round from the server
     */
    public void getGameRound() {
        round = ClientModel.boggledServant.playRound(gsID);
    } // end of getGGameRound

    /**
     * Retrieves the current round time from the server
     *
     * @return The current round time in seconds
     * @throws GameTimeout If the round has timed out
     */
    public int getCurrentRoundTime() throws GameTimeout {
        return ClientModel.boggledServant.getCurrentRoundTime(gsID);
    } // end of getCurrentRoundTime

    /**
     * Sends a word to the server to be evaluated
     *
     * @param word The word to send
     * @throws InvalidWord If the word is invalid
     */
    public void sendWord(String word) throws InvalidWord {
        ClientModel.boggledServant.sendWord(playerID, gsID, word);
        wordEntry.add(word);
    } // end of sendWord

    /**
     * Retrieves the current game points for the player
     *
     * @return The game points as a String
     */
    public String getGamePoints() {
        String[] players = round.players;

        for (String entry : players) {
            String otherUsername = entry.split("-")[0];
            String points = entry.split("-")[2];

            if (otherUsername.equals(username)) {
                return points;
            }
        }
        return "0";
    } // end of getGamePoints

    /**
     * Checks if a word has already been entered by the player
     *
     * @param word The word to check
     * @return True if the word has already been entered, false otherwise
     */
    public boolean isAlreadyInTheEntry(String word) {
        return wordEntry.contains(word);
    } // end of isAlreadyInTheEntry

    /**
     * Checks if the round evaluation is done
     *
     * @return True if the round evaluation is done, false otherwise
     */
    public boolean roundEvaluationDone() {
        return ClientModel.boggledServant.roundEvaluationDone(gsID);
    } // end of roundEvaluationDone

    /**
     * Retrieves the winner of the current round
     *
     * @return The username of the round winner
     */
    public String getRoundWinner() {
        return ClientModel.boggledServant.getRoundWinner(gsID);
    } // end of getRoundWinner

    /**
     * Retrieves the winner of the game session
     *
     * @return The username of the game winner
     */
    public String getGameWinner() {
        return ClientModel.boggledServant.getGameWinner(gsID);
    } // end of getGameWinner

    /**
     * Gets the current game round
     *
     * @return The current game round
     */
    public GameRound getRound() {
        return round;
    }

    /**
     * Gets the username of the player
     *
     * @return The username of the player
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sends a request to the server to leave the game session and log out
     */
    public void leave() {
        ClientModel.boggledServant.leaveGame(playerID, gsID);
        ClientModel.boggledServant.logout(playerID);
    } // end of leave

    /**
     * Clears the set of word entries
     */
    public void clearWordEntries() {
        wordEntry.clear();
    } // end of clearWordEntries
} // end of GameModel class
