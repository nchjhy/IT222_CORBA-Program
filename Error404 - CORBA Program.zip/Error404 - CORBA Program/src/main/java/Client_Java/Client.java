package Client_Java;

import Client_Java.controller.Login;
import Client_Java.model.ClientModel;
import Client_Java.model.LoginModel;
import Client_Java.view.LoginView;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * The Client class serves as the entry point for the JavaFX
 */
public class Client extends Application {

    /** The main stage of the application. */
    public static Stage MAIN_STAGE;

    /**
     * The main method is used to launch the JavaFX
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        // Initialize the client model and connect to the server
        ClientModel clientModel = new ClientModel();
        clientModel.connectToServer();

        // Launch the JavaFX application
        launch(args);
    } // end of main

    /**
     * The start method is called when the JavaFX application is launched
     * It sets up the initial stage and initializes the login screen
     * @param stage The primary stage for the application
     */
    public void start(Stage stage) {
        // Set the main stage
        MAIN_STAGE = stage;

        // Initialize the login screen
        Login login = new Login(new LoginModel(), new LoginView());
        login.init();

        // Configure the stage properties
        stage.setTitle("Boggled Word Factory");
        stage.setResizable(false);
        stage.setFullScreen(false);
        stage.show();
    }
} // end of Client class
