package Server_Java.controller.popups;

import Server_Java.model.popups.DeletePlayerModel;
import Server_Java.view.popups.DeletePlayerView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
/**
 * This class handles the functionality of the
 * delete player popup. It interacts with the {@code DeletePlayerView} and {@code DeletePlayerModel}
 * to manage the user interface and business logic for deleting a player.
 */
public class DeletePlayer {
    private DeletePlayerView view;
    private DeletePlayerModel model;
    /**
     * Constructs a {@code DeletePlayer} object with the specified model.
     *
     * @param model the {@code DeletePlayerModel} used for business logic.
     */
    public DeletePlayer(DeletePlayerModel model) {
        this.model = model;
    }

    /**
     * Initializes and displays the delete player popup window.
     * Loads the FXML layout, sets up the stage properties, and shows the popup.
     */
    public void init() {
        try {
            Stage popupStage = new Stage();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/server/DeleteUserView.fxml"));

            Scene scene = new Scene(loader.load());

            view = loader.getController();

            popupStage.setFullScreen(false);
            popupStage.setResizable(false);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setScene(scene);
            popupStage.show();

            setUpDeleteBT();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets up the action for the delete button. When the delete button is clicked,
     * it attempts to delete the player using the model. Displays appropriate notice messages
     * based on the result.
     */
    public void setUpDeleteBT() {
        view.getDeleteBT().setOnAction(event -> {
            if (model.deletePlayer(view.getUsernameTF().getText().trim())) {
                setNoticeMessage("Successfully deleted player");
            } else {
                setNoticeMessage("Failed to delete player");
            }
        });
    }

    /**
     * Sets a notice message in the view and clears it after a delay.
     *
     * @param notice the {@code String} message to be displayed.
     */
    public void setNoticeMessage(String notice) {
        view.getNoticeLB().setText(notice);

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> view.getNoticeLB().setText(""));
            }
        }, 3000);
    }
} // end of DeletePlayer class
