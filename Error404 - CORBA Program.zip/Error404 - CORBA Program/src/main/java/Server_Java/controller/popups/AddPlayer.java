package Server_Java.controller.popups;

import BoggledApp.AccountAlreadyExists;
import Server_Java.model.popups.AddPlayerModel;
import Server_Java.view.popups.AddPlayerView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This class handles the creation and functionality of the
 * add player popup. It interacts with the {@code AddPlayerView} and {@code AddPlayerModel}
 * to manage the user interface and business logic for adding a new player.
 */
public class AddPlayer {
    private AddPlayerView view;
    private AddPlayerModel model;
    /**
     * Constructs an {@code AddPlayer} object with the specified model.
     *
     * @param model the {@code AddPlayerModel} used for business logic.
     */
    public AddPlayer(AddPlayerModel model) {
        this.model = model;
    }

    /**
     * Initializes and displays the add player popup window.
     * Loads the FXML layout, sets up the stage properties, and shows the popup.
     */
    public void init() {
        try {
            Stage popupStage = new Stage();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/server/AddUserView.fxml"));

            Scene scene = new Scene(loader.load());

            view = loader.getController();

            popupStage.setFullScreen(false);
            popupStage.setResizable(false);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setScene(scene);
            popupStage.show();

            setUpAddBT();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets up the action for the save button. When the save button is clicked,
     * it validates the input fields and attempts to add a new player using the model.
     * Displays appropriate notice messages based on the result.
     */
    public void setUpAddBT() {
        view.getSaveBT().setOnAction(event -> {
            if (view.getUsernameTF().getText().isEmpty() || view.getPasswordTF().getText().isEmpty()) {
                setNoticeMessage("Please supply all necessary details");
            } else {
                try {
                    if (model.addPlayer(view.getUsernameTF().getText(), view.getPasswordTF().getText())) {
                        setNoticeMessage("Successfully added user");
                    } else {
                        setNoticeMessage("Unable to add user");
                    }
                } catch (AccountAlreadyExists e) {
                    setNoticeMessage("An existing account has the same username. Unable to add user");
                }
            }
        });
    }

    /**
     * Sets a notice message in the view and clears it after a delay.
     *
     * @param notice the {@code String} message to be displayed.
     */
    public void setNoticeMessage(String notice) {
        view.getNoticeLB().setText(notice);

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> view.getNoticeLB().setText(""));
            }
        }, 3000);
    }
} // end of AddPlayer class
