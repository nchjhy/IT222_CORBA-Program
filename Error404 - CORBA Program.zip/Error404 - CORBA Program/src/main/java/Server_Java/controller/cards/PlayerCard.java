package Server_Java.controller.cards;

import Server_Java.view.cards.PlayerCardView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

import java.io.IOException;
/** This class is responsible for creating a player card UI component.
 * The card displays a player's username and their online/offline status.
 */
public class PlayerCard {

    /**
     * Constructs a new {@code PlayerCard} object.
     */
    public PlayerCard() {}

    /**
     * Creates a player card Node by loading the FXML layout and setting the player's
     * username and status.
     *
     * @param player a {@code String} containing the player's username and status,
     *               formatted as "username-status", where status is "1" for online
     *               and any other value for offline.
     * @return a {@code Node} representing the player card, or {@code null} if an
     *         error occurs during loading.
     */
    public static Node createCard(String player) {
        try {
            FXMLLoader loader = new FXMLLoader(PlayerCard.class.getResource("/fxml/server/playerCard.fxml"));

            Node card = loader.load();

            PlayerCardView view = loader.getController();

            String username = player.split("-")[0];
            String status = player.split("-")[1].equals("1") ? "online" : "offline";

            view.getUsernameLB().setText(username);
            view.getStatusLB().setText(status);

            return card;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    } // end of createCard
} // end of PlayerCard
