package Server_Java.controller;

import BoggledApp.Player;
import Server_Java.Server;
import Server_Java.controller.popups.AddPlayer;
import Server_Java.controller.popups.DeletePlayer;
import Server_Java.model.AdminModel;
import Server_Java.model.ServerModel;
import Server_Java.model.popups.AddPlayerModel;
import Server_Java.model.popups.DeletePlayerModel;
import Server_Java.view.AdminView;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;
import java.sql.Time;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

/**
 * This class manages the admin panel of the server application. It
 * handles the initialization of the admin interface and sets up various functionalities
 * such as leaderboards, player management, and application settings.
 */
public class Admin {
    public static Scene ADMIN_SCENE;
    private AdminModel model;
    private AdminView view;

    /**
     * Constructs an {@code Admin} object with the specified model and view.
     *
     * @param model the {@code AdminModel} used for business logic.
     * @param view the {@code AdminView} used for displaying the admin interface.
     */
    public Admin(AdminModel model, AdminView view){
        this.model = model;
        this.view = view;
    }

    /**
     * Initializes and displays the admin panel.
     * Loads the FXML layout, sets up the stage properties, and shows the admin scene.
     */
    public void init(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/server/AdminView.fxml"));

            ADMIN_SCENE = new Scene(loader.load());

            view = loader.getController();

            Server.MAIN_STAGE.setScene(ADMIN_SCENE);

            setUpLeaderboardsPanel();
            setUpPlayersPanel();
            setUpAddPlayerBT();
            setUpDeletePlayerBT();
            setUpSearchFunction();
            setUpConfigurationSettings();
            setUpExitApp();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets up the leaderboards panel by displaying the current leaderboard data
     * and adding a refresh button functionality.
     */
    private void setUpLeaderboardsPanel() {
        view.showLeaderboards(model.getLeaderboard());

        view.getLeaderboardPanelRefreshBT().setOnAction(event -> {
            view.showLeaderboards(model.getLeaderboard());
        });
    } // end of setUpLeaderboardsBT

    /**
     * Sets up the players panel by displaying the current list of registered players
     * and adding a refresh button functionality.
     */
    private void setUpPlayersPanel() {
        view.showPlayers(model.getPlayers());

        view.getPlayerPanelRefreshBT().setOnAction(event -> {
            view.showPlayers(model.getPlayers());
        });
    } // end of setUpPlayersPanel

    /**
     * Sets up the add player button to open the add player popup when clicked.
     */
    private void setUpAddPlayerBT() {
        view.getAddPlayerBT().setOnAction(event -> {
            AddPlayer addPlayer = new AddPlayer(new AddPlayerModel());
            addPlayer.init();
        });
    }

    /**
     * Sets up the delete player button to open the delete player popup when clicked.
     */
    private void setUpDeletePlayerBT() {
        view.getDeletePlayerBT().setOnAction(event -> {
            DeletePlayer deletePlayer = new DeletePlayer(new DeletePlayerModel());
            deletePlayer.init();
        });
    }

    /**
     * Sets up the search functionality to filter and display players and leaderboards
     * based on the search keyword.
     */
    private void setUpSearchFunction() {
        view.getSearchBT().setOnAction(event -> {
            String keyword = view.getSearchTF().getText();

            if (!keyword.isEmpty()) {
                List<String> playerList = model.getPlayers(keyword);
                List<String> leaderboardList = model.getLeaderboard(keyword);

                view.showPlayers(playerList);
                view.showLeaderboards(leaderboardList);
            }
        });
    }

    /**
     * Sets up the configuration settings panel to allow the admin to change
     * game settings such as round length and waiting time.
     */
    private void setUpConfigurationSettings() {
        view.getRoundDP().setValue(ServerModel.ROUND_LENGTH);
        view.getLobbyDP().setValue(ServerModel.WAITING_TIME);

        view.getSaveConfigBT().setOnAction(event -> {
            ServerModel.WAITING_TIME = view.getLobbyDP().getValue();
            ServerModel.ROUND_LENGTH = view.getRoundDP().getValue();

            view.getNoticeLB().setText("Game Settings Changed");

            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    Platform.runLater(() -> view.getNoticeLB().setText(""));
                }
            }, 3000);
        });
    }

    /**
     * Sets up the exit application functionality to save configuration settings
     * and exit the application when the main stage is closed.
     */
    private void setUpExitApp() {
        Server.MAIN_STAGE.setOnCloseRequest(windowEvent -> {
            ServerModel.saveConfig();
            System.exit(0);
        });
    } // end of setUpExitApp
}
