package Server_Java.view;

import Client_Java.controller.cards.LeaderboardCard;
import Server_Java.controller.cards.PlayerCard;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Represents the admin view in the server GUI.
 */
public class AdminView {
    @FXML
    private Label noticeLB;
    @FXML
    private Button addPlayerBT, deletePlayerBT, saveConfigBT, searchBT, playerPanelRefreshBT, leaderboardPanelRefreshBT;
    @FXML
    private ComboBox<Integer> lobbyDP, roundDP;
    @FXML
    private FlowPane playerPane, leaderboardPane;
    @FXML
    private TextField searchTF;

    /**
     * Initializes the admin view.
     */
    public AdminView(){}

    /**
     * Initializes the lobby and round timer combo boxes.
     */
    @FXML
    public void initialize() {
        ObservableList<Integer> values = FXCollections.observableArrayList(
                IntStream.rangeClosed(1, 100).boxed().collect(Collectors.toList())
        );

        lobbyDP.setItems(values);
        roundDP.setItems(values);
    }

    /**
     * Displays the leaderboards.
     *
     * @param leaderboard The list of strings representing leaderboard entries.
     */
    public void showLeaderboards(List<String> leaderboard) {
        List<Node> cards = new ArrayList<>();

        for (String row : leaderboard) {
            cards.add(LeaderboardCard.createCard(row));
        }
        leaderboardPane.getChildren().clear();
        leaderboardPane.getChildren().addAll(cards);
    }

    /**
     * Displays the player cards.
     *
     * @param players The list of strings representing player entries.
     */
    public void showPlayers(List<String> players) {
        List<Node> cards = new ArrayList<>();

        for (String row : players) {
            cards.add(PlayerCard.createCard(row));
        }
        playerPane.getChildren().clear();
        playerPane.getChildren().addAll(cards);
    }

    // Getter methods for accessing UI components
    public Label getNoticeLB() {
        return noticeLB;
    }

    public Button getAddPlayerBT() {
        return addPlayerBT;
    }

    public Button getDeletePlayerBT() {
        return deletePlayerBT;
    }

    public Button getSaveConfigBT() {
        return saveConfigBT;
    }

    public Button getSearchBT() {
        return searchBT;
    }

    public Button getPlayerPanelRefreshBT() {
        return playerPanelRefreshBT;
    }

    public Button getLeaderboardPanelRefreshBT() {
        return leaderboardPanelRefreshBT;
    }

    public TextField getSearchTF() {
        return searchTF;
    }

    public ComboBox<Integer> getLobbyDP() {
        return lobbyDP;
    }

    public ComboBox<Integer> getRoundDP() {
        return roundDP;
    }
}
