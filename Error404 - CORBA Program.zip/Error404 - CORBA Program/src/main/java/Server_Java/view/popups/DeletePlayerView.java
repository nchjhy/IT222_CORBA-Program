package Server_Java.view.popups;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Represents the view for deleting a player in the server GUI.
 */
public class DeletePlayerView {
    @FXML
    private Label noticeLB;
    @FXML
    private TextField usernameTF;
    @FXML
    private Button deleteBT;

    /**
     * Constructs a new DeletePlayerView.
     */
    public DeletePlayerView() {}

    /**
     * Gets the label displaying the notice.
     *
     * @return The label displaying the notice.
     */
    public Label getNoticeLB() {
        return noticeLB;
    }

    /**
     * Gets the text field for entering the username.
     *
     * @return The text field for entering the username.
     */
    public TextField getUsernameTF() {
        return usernameTF;
    }

    /**
     * Gets the button for deleting the player.
     *
     * @return The button for deleting the player.
     */
    public Button getDeleteBT() {
        return deleteBT;
    }
} // end of DeletePlayerView class
