package Server_Java.view.popups;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * Represents the view for adding a player in the server GUI.
 */
public class AddPlayerView {
    @FXML
    private Label noticeLB;
    @FXML
    private TextField usernameTF, passwordTF;
    @FXML
    private Button saveBT;

    /**
     * Constructs a new AddPlayerView.
     */
    public AddPlayerView() {}

    /**
     * Gets the label displaying the notice.
     *
     * @return The label displaying the notice.
     */
    public Label getNoticeLB() {
        return noticeLB;
    }

    /**
     * Gets the text field for entering the username.
     *
     * @return The text field for entering the username.
     */
    public TextField getUsernameTF() {
        return usernameTF;
    }

    /**
     * Gets the text field for entering the password.
     *
     * @return The text field for entering the password.
     */
    public TextField getPasswordTF() {
        return passwordTF;
    }

    /**
     * Gets the button for saving the player.
     *
     * @return The button for saving the player.
     */
    public Button getSaveBT() {
        return saveBT;
    }
} // end of AddPlayerView class
