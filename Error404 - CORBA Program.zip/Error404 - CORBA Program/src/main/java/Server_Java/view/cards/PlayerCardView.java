package Server_Java.view.cards;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * Represents the view for a player card in the server GUI.
 */
public class PlayerCardView {
    @FXML
    private Label usernameLB, statusLB;

    /**
     * Constructs a new PlayerCardView.
     */
    public PlayerCardView() {}

    /**
     * Gets the label displaying the username.
     *
     * @return The label displaying the username.
     */
    public Label getUsernameLB() {
        return usernameLB;
    }

    /**
     * Gets the label displaying the status.
     *
     * @return The label displaying the status.
     */
    public Label getStatusLB() {
        return statusLB;
    }
} // end of PlayerCardView
