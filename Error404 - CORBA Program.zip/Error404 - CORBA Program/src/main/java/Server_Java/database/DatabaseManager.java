package Server_Java.database;

import BoggledApp.AccountAlreadyExists;
import BoggledApp.AlreadyLoggedIn;
import BoggledApp.DoesNotExist;
import BoggledApp.Player;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
/**
 * This class handles all database operations for the Boggled application.
 * It manages player login/logout, game sessions, player points, and maintains the leaderboard.
 */
public class DatabaseManager {
    private static String URL = "jdbc:mysql://localhost:3306/boggled";
    private static String USER = "root";
    private static String PASSWORD = "";
    private static String sql;
    private static Connection con;
    private static Statement stmt;
    private static PreparedStatement pstmt;
    private static ResultSet rs;

    // Static block to establish the database connection
    static {
        try {
            con = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    /**
     * Logs in a player with the specified username and password.
     *
     * @param username the username of the player
     * @param password the password of the player
     * @return the player ID if login is successful
     * @throws AlreadyLoggedIn if the player is already logged in
     * @throws DoesNotExist if the player does not exist in the database
     */
    public static int login(String username, String password) throws AlreadyLoggedIn, DoesNotExist {
        sql = "SELECT playerID, status FROM player WHERE username = ? AND password = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int playerID = rs.getInt("playerID");
                int status = rs.getInt("status");
                if (status == 1) {
                    throw new AlreadyLoggedIn("Player is already logged in.");
                } else {
                    sql = "UPDATE player SET status = 1 WHERE playerID = ?";

                    pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, playerID);
                    pstmt.executeUpdate();
                    return playerID;
                }
            } else {
                throw new DoesNotExist("Player does not exist in the database.");
            }
        } catch (SQLException e) {
            System.err.println("Error while logging in: " + e.getMessage());
            throw new RuntimeException("Error while logging in", e);
        }
    }

    /**
     * Logs out a player with the specified player ID.
     *
     * @param playerID the ID of the player
     */
    public static void logout(int playerID) {
        sql = "UPDATE player SET status = 0 WHERE playerID = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, playerID);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while logging out: " + e.getMessage());
        }
    }

    /**
     * Retrieves the last game session ID from the database.
     *
     * @return the last game session ID
     */
    public static int getLastGameSessionID() {
        sql = "SELECT MAX(gsID) AS maxID FROM gamesession";

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                return rs.getInt("maxID");
            }
        } catch (SQLException e) {
            System.err.println("Error while getting last game session ID: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Creates a new game session with the specified game session ID.
     *
     * @param gsID the game session ID
     */
    public static void createGameSession(int gsID){
        sql = "INSERT INTO gamesession(gsID, timestamp) " +
                "VALUES(?, NOW())";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, gsID);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while adding game session: " + e.getMessage());
        }
    }

    /**
     * Updates the game session with the specified game session ID and game winner.
     *
     * @param gsID the game session ID
     * @param gameWinner the ID of the winning player
     */
    public static void updateGameSession(int gsID, int gameWinner) {
        sql = "UPDATE gamesession SET gameWinner = ? WHERE gsID = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, gameWinner);
            pstmt.setInt(2, gsID);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while updating game session: " + e.getMessage());
        }
    }

    /**
     * Updates the points for a list of players.
     *
     * @param players the list of players to update
     */
    public static void updatePlayerPoints(List<Player> players) {
        sql = "UPDATE player SET points = ? WHERE playerID = ?";

        try {
            for (Player player : players) {
                pstmt = con.prepareStatement(sql);
                pstmt.setInt(1, player.totalPoints);
                pstmt.setInt(2, player.playerID);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("Error while updating player points: " + e.getMessage());
        }
    }

    /**
     * Updates the win count for a player with the specified player ID.
     *
     * @param playerID the ID of the player
     */
    public static void updateWin(int playerID) {
        sql = "SELECT playerID FROM record WHERE playerID = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, playerID);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                sql = "UPDATE record SET win = win + 1 WHERE playerID = ?";

                try {
                    pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, playerID);
                    pstmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                sql = "INSERT INTO record (playerID, win)" +
                        "VALUES (?, 1)";

                try {
                    pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, playerID);
                    pstmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if a word exists in the word bank.
     *
     * @param word the word to check
     * @return true if the word exists, false otherwise
     */
    public static boolean crossCheckWordBank(String word) {
        sql = "SELECT COUNT(*) AS count FROM wordbank WHERE word = ?";

        try {
            // Query to check if the word exists in the wordbank table
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, word);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt("count");
                // If count is greater than 0, the word exists in the wordbank table
                return count > 0;
            }
        } catch (SQLException e) {
            // Handle SQL exception
            System.err.println("Error while checking if the word exists in the database: " + e.getMessage());
        }
        // Default return false if an exception occurs or no result is found
        return false;
    }

    /**
     * Retrieves the leaderboard entries.
     *
     * @return a list of leaderboard entries in the format "username-wins"
     */
    public static List<String> getLeaderboardEntries() {
        List<String> leaderboard = new ArrayList<>();

        sql = "SELECT username, win FROM player LEFT JOIN record on player.playerID = record.playerID ORDER BY win DESC";
        try {
            // Query to select usernames and points from the player table, ordered by points descending
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            // Iterate through the result set and construct leaderboard entries
            while (rs.next()) {
                String username = rs.getString("username");
                long wins = rs.getLong("win");
                // Construct leaderboard entry in the format "username-win" and add to the list
                leaderboard.add(username + "-" + wins);
            }
        } catch (SQLException e) {
            // Handle SQL exception
            System.err.println("Error while getting leaderboard entries: " + e.getMessage());
        }
        return leaderboard;
    }

    /**
     * Retrieves the leaderboard entries that match the specified keyword.
     *
     * @param keyword the keyword to match
     * @return a list of leaderboard entries in the format "username-wins"
     */
    public static List<String> getLeaderboardEntries(String keyword) {
        List<String> leaderboard = new ArrayList<>();

        sql = "SELECT username, win FROM player p LEFT JOIN record r on p.playerID = r.playerID WHERE username LIKE ? ORDER BY win DESC";
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + keyword + "%");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String username = rs.getString("username");
                long wins = rs.getLong("win");
                leaderboard.add(username + "-" + wins);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return leaderboard;
    }

    /**
     * Retrieves the details of a player with the specified player ID.
     *
     * @param playerID the ID of the player
     * @return a Player object containing the player's details, or null if the player does not exist
     */
    public static Player getPlayer(int playerID) {
        sql = "SELECT playerID, username, points FROM player WHERE playerID=?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, playerID);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String username = rs.getString("username");
                int points = rs.getInt("points");
                return new Player(playerID,username,points);
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving player details: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves the list of all players.
     *
     * @return a list of players in the format "username-status"
     */
    public static List<String> getPlayerList() {
        List<String> players = new ArrayList<>();

        sql = "SELECT username, status FROM player";
        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String username = rs.getString("username");
                int status = rs.getInt("status");

                players.add(username + "-" + status);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return players;
    }

    /**
     * Retrieves the list of players that match the specified keyword.
     *
     * @param keyword the keyword to match
     * @return a list of players in the format "username-status"
     */
    public static List<String> getPlayerList(String keyword) {
        List<String> players = new ArrayList<>();

        sql = "SELECT username, status FROM player WHERE username LIKE ?";
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + keyword + "%");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String username = rs.getString("username");
                int status = rs.getInt("status");

                players.add(username + "-" + status);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return players;
    }

    /**
     * Adds a new player with the specified username and password.
     *
     * @param username the username of the player
     * @param password the password of the player
     * @return true if the player is added successfully, false if the player already exists
     * @throws AccountAlreadyExists if the account already exists
     */
    public static boolean addPlayer(String username, String password) throws AccountAlreadyExists {
        sql = "SELECT username FROM player WHERE username = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                throw new AccountAlreadyExists("account already exists");
            } else {
                sql = "INSERT INTO player (username, password) " +
                        "VALUES (?, ?)";

                try {
                    pstmt = con.prepareStatement(sql);
                    pstmt.setString(1, username);
                    pstmt.setString(2, password);
                    int success = pstmt.executeUpdate();

                    if (success > 0) {
                        return true;
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    /**
     * Deletes a player with the specified username.
     *
     * @param username the username of the player
     * @return true if the player is deleted successfully, false otherwise
     */
    public static boolean deletePlayer(String username) {
        sql = "DELETE FROM player WHERE username = ?";

        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, username);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                return true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
}
