package Server_Java;

import BoggledApp.BoggledAppServer;
import BoggledApp.BoggledAppServerHelper;
import Server_Java.controller.Admin;
import Server_Java.model.AdminModel;
import Server_Java.model.BoggledServant;
import Server_Java.model.ServerModel;
import Server_Java.view.AdminView;
import javafx.application.Application;
import javafx.stage.Stage;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import java.io.IOException;

/**
 * The main entry point for the Boggled server application.
 */
public class Server extends Application {
    public static Stage MAIN_STAGE;

    /**
     * Main method to start the Boggled server.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        try {
            // embed the starting of the ORB daemon
            Runtime.getRuntime().exec("orbd 2023-2_9438-finteamerror404-java -ORBInitialPort 12345 -ORBInitialHost localhost");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Start the server thread
        Thread serverThread = new Thread(Server::startServer);
        serverThread.setDaemon(true);
        serverThread.start();

        launch(args);
    }

    /**
     * Starts the JavaFX application.
     *
     * @param stage The primary stage for this application.
     */
    @Override
    public void start(Stage stage) {
        MAIN_STAGE = stage;

        // Load server configuration and initialize admin interface
        ServerModel.loadConfig();
        Admin admin = new Admin(new AdminModel(), new AdminView());
        admin.init();

        // Set up the primary stage
        stage.setTitle("Server");
        stage.setResizable(false);
        stage.setFullScreen(false);
        stage.show();
    }

    /**
     * Starts the Boggled server.
     */
    public static void startServer() {
        String[] args = {"-ORBInitialPort", "12345", "-ORBInitialHost", "localhost"};
        try {
            // create and initialize the ORB
            ORB orb = ORB.init(args, null);

            // get reference to rootpoa & activate the POAManager
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();

            // create servant and register it with the ORB
            BoggledServant boggledServant = new BoggledServant();

            // get object reference from the servant
            org.omg.CORBA.Object ref = rootPOA.servant_to_reference(boggledServant);
            BoggledAppServer href = BoggledAppServerHelper.narrow(ref);

            // get the root naming context
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

            // Use NamingContextExt which is part of the Interoperable
            // Naming Service (INS) specification.
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            // bind the Object Reference in Naming
            String name = "ServerService";
            NameComponent[] path = ncRef.to_name(name);
            ncRef.rebind(path, href);

            System.out.println("Server ready and waiting...");

            // wait for invocations from clients
            orb.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Closing server connection...");
    }
}

