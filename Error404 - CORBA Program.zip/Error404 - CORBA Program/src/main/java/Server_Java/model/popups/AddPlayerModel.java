package Server_Java.model.popups;

import BoggledApp.AccountAlreadyExists;
import Server_Java.database.DatabaseManager;

/**
 * This class provides the functionality to add a new player
 * to the database through the {@link DatabaseManager}.
 */
public class AddPlayerModel {

    /**
     * Constructs an {@code AddPlayerModel} object.
     */
    public AddPlayerModel() {}

    /**
     * Adds a new player with the specified username and password.
     *
     * @param username the username of the new player
     * @param password the password of the new player
     * @return {@code true} if the player was added successfully, {@code false} otherwise
     * @throws AccountAlreadyExists if an account with the specified username already exists
     */
    public boolean addPlayer(String username, String password) throws AccountAlreadyExists {
        return DatabaseManager.addPlayer(username, password);
    }
} // end of AddPlayerModel class
