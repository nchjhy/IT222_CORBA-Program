package Server_Java.model.popups;

import Server_Java.database.DatabaseManager;
/**
 * This class provides the functionality to delete a player
 * from the database through the {@link DatabaseManager}.
 */
public class DeletePlayerModel {

    /**
     * Constructs a {@code DeletePlayerModel} object.
     */
    public DeletePlayerModel() {}

    /**
     * Deletes a player with the specified username from the database.
     *
     * @param username the username of the player to delete
     * @return {@code true} if the player was deleted successfully, {@code false} otherwise
     */
    public boolean deletePlayer(String username) {
        return DatabaseManager.deletePlayer(username);
    }
} // end of DeletePlayerModel class
