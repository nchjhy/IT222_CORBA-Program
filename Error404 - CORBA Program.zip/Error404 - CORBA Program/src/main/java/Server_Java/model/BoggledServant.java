package Server_Java.model;

import BoggledApp.*;
import Client_Java.model.ClientModel;
import Server_Java.database.DatabaseManager;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * This class implements the BoggledAppServer interface and provides
 * the server-side logic for the Boggled game.
 *
 * The methods mostly reference methods from {@link GameSession}
 */
public class BoggledServant extends BoggledAppServerPOA {
    private AtomicReference<GameSession> lobbyGame = new AtomicReference<>(null); // Atomic reference to hold the lobby game, if any.
    private HashMap<Integer, GameSession> ongoingGameSessions = new HashMap<>(); // HashMap to store ongoing game sessions, keyed by game session ID.
    private AtomicInteger waitingTime = new AtomicInteger(0); // Atomic integer to track the waiting time for players in the lobby game.

    /**
     * Constructor with a thread that handles the lobby games. If a player initiates a game but the lobby game is null,
     * a lobby game will be created then the game manager thread handles the lobby game to wait for players. If the
     * time expires and the game lobby is valid, the game will be added to the list of ongoing game sessions, else,
     * it will be set to null.
     */
    public BoggledServant() {
        Thread gameManagerThread = new Thread(() -> {
            try {
                while (true) {
                    if (lobbyGame.get() != null) {
                        waitingTime.set(ServerModel.WAITING_TIME);

                        while (waitingTime.get() != -1) {
                            Thread.sleep(1000);
                            waitingTime.getAndDecrement();

                            if (lobbyGame.get().getPlayerCount() == 0) {
                                waitingTime.set(-1);
                                break;
                            }
                        }

                        if (lobbyGame.get().isValid()) {
                            lobbyGame.get().startGame();

                            ongoingGameSessions.put(lobbyGame.get().getGsID(), lobbyGame.get());

                            DatabaseManager.createGameSession(lobbyGame.get().getGsID());
                        }

                        lobbyGame.set(null);
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        gameManagerThread.setDaemon(true);
        gameManagerThread.start();
    }

    /**
     * Handles the login logic, utilizes the database manager to get the result and handles the result processing
     *
     * @param username the username of the player
     * @param password the password of the player
     * @return the ID of the logged-in player
     * @throws AlreadyLoggedIn if the player is already logged in
     * @throws DoesNotExist if the player does not exist
     */
    @Override
    public int login(String username, String password) throws AlreadyLoggedIn, DoesNotExist {
        try {
            return DatabaseManager.login(username, password);
        } catch (AlreadyLoggedIn e) {
            throw new AlreadyLoggedIn(e.getMessage());
        } catch (DoesNotExist e) {
            throw new DoesNotExist(e.getMessage());
        }
    }

    /**
     * Utilizes the database manager to log out the player. Also remove the player from an ongoing game session if applicable
     *
     * @param playerID the ID of the player to log out
     */
    @Override
    public void logout(int playerID) {
        try {
            DatabaseManager.logout(playerID);
            if (lobbyGame.get() != null) {
                lobbyGame.get().removePlayer(playerID);
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid player ID format: " + playerID);
        }
    }

    /**
     * Retrieves the username of a player.
     *
     * @param playerID the ID of the player
     * @return the username of the player
     */
    @Override
    public String getUsername(int playerID) {
        return DatabaseManager.getPlayer(playerID).username;
    }

    /**
     * Adds a player to a game session that has still not started. if the lobby game is not created yet, a lobby game
     * instance will be created where the player will be added in. If there is a lobby game, the player will simply
     * be added in the game session.
     *
     * @param playerID the id of the player
     * @return the gsID of the lobby game
     */
    @Override
    public int joinGameSession(int playerID) {
        if (lobbyGame.get() == null) {
            int latestGsID = DatabaseManager.getLastGameSessionID();
            lobbyGame.set(new GameSession(++latestGsID));
        }
        lobbyGame.get().addPlayer(playerID);

        return lobbyGame.get().getGsID();
    }

    /**
     * Retrieves the current waiting time for players in the lobby game.
     *
     * @return the current waiting time
     * @throws GameTimeout if the waiting time has expired
     */
    @Override
    public int getCurrentWaitingTime() throws GameTimeout {
        if (waitingTime.get() == -1) {
            throw new GameTimeout("countdown expired");
        }
        return waitingTime.get();
    }

    /**
     * Retrieves the number of players currently waiting in the lobby game.
     *
     * @return the number of waiting players
     */
    @Override
    public int getNumberOfWaitingPlayers() {
        return lobbyGame.get().getPlayerCount();
    }

    /**
     * Retrieves the current round time for the specified game session.
     *
     * @param gsID the ID of the game session
     * @return the current round time
     * @throws GameTimeout if the round time has expired
     */
    @Override
    public int getCurrentRoundTime(int gsID) throws GameTimeout {
        int currentRoundTime = ongoingGameSessions.get(gsID).getRoundTime();
        if (currentRoundTime == -1) {
            throw new GameTimeout("countdown expired");
        }
        return currentRoundTime;
    } // end of getCurrentRoundTime

    /**
     * Initiates the next round of the game for the specified game session.
     *
     * @param gsID the ID of the game session
     * @return the new round
     */
    @Override
    public GameRound playRound(int gsID) {
        return ongoingGameSessions.get(gsID).getNextRound();
    }

    /**
     * Processes a word submitted by a player in the specified game session.
     *
     * @param playerID the ID of the player
     * @param gsID     the ID of the game session
     * @param word     the word submitted by the player
     * @throws InvalidWord if the word is invalid
     */
    @Override
    public void sendWord(int playerID, int gsID, String word) throws InvalidWord {
        // check if the word length is greater than 3
        if (word.length() < 4) {
            throw new InvalidWord("invalid word");
        }

        // check if the letters are included in the character set
        StringBuilder characterSet = new StringBuilder(ongoingGameSessions.get(gsID).getCharacterSet());
        for (char letter : word.toCharArray()) {
            int index = characterSet.indexOf(String.valueOf(letter));

            if (index != -1) {
                characterSet.deleteCharAt(index);
            } else {
                throw new InvalidWord("invalid word");
            }
        }

        // check if the word is included in the database
        if (!DatabaseManager.crossCheckWordBank(word)) {
            throw new InvalidWord("invalid word");
        }

        ongoingGameSessions.get(gsID).addWordEntry(playerID, word);
    } // end of sendWord

    /**
     * Retrieves the winner of the current round in the specified game session.
     *
     * @param gsID the ID of the game session
     * @return the username of the round winner
     */
    @Override
    public String getRoundWinner(int gsID) {
        return ongoingGameSessions.get(gsID).getRoundWinner();
    }

    /**
     * Retrieves the winner of the game in the specified game session.
     *
     * @param gsID the ID of the game session
     * @return the username of the game winner
     */
    @Override
    public String getGameWinner(int gsID) {
        return ongoingGameSessions.get(gsID).getGameWinner();
    }

    /**
     * Checks if round evaluation is complete for the specified game session.
     *
     * @param gsID the ID of the game session
     * @return {@code true} if round evaluation is complete, {@code false} otherwise
     */
    @Override
    public boolean roundEvaluationDone(int gsID) {
        return ongoingGameSessions.get(gsID).roundEvaluationDone();
    }

    /**
     * Removes a player from the specified game session.
     *
     * @param playerID the ID of the player
     * @param gsID     the ID of the game session
     */
    @Override
    public void leaveGame(int playerID, int gsID) {
        if (ongoingGameSessions.containsKey(gsID)) {
            ongoingGameSessions.get(gsID).removePlayer(playerID);
        } else {
            lobbyGame.get().removePlayer(playerID);
        }
    }

    /**
     * Retrieves the leaderboard entries.
     *
     * @return an array of leaderboard entries
     */
    @Override
    public String[] getLeaderboard() {
        List<String> leaderboard = DatabaseManager.getLeaderboardEntries();

        return leaderboard.toArray(new String[0]);
    }
} // end of BoggledServantNew
