package Server_Java.model;

import java.io.*;

/**
 * Manages server configurations including host address, port, waiting time, and round length.
 */
public class ServerModel {
    public static String HOST_ADDRESS; //Host address
    public static int PORT, WAITING_TIME, ROUND_LENGTH; //Port, lobby timer, round timer

    /**
     * Loads configurations from a file.
     */
    public static void loadConfig() {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/.config"))){
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(":");

                String key = parts[0];
                String value = parts[1];
                if (key.equalsIgnoreCase("host")) {
                    HOST_ADDRESS = value;
                }
                if (key.equalsIgnoreCase("port")) {
                    PORT = Integer.parseInt(value);
                }
                if (key.equalsIgnoreCase("waitingTime")) {
                    WAITING_TIME = Integer.parseInt(value);
                }
                if (key.equalsIgnoreCase("roundTime")) {
                    ROUND_LENGTH = Integer.parseInt(value);
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("- Configurations loaded");
    }

    /**
     * Saves configurations to a file.
     */
    public static void saveConfig() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/.config"))) {
            writer.write("host:" + HOST_ADDRESS + "\n");
            writer.write("port:" + PORT + "\n");
            writer.write("waitingTime:" + WAITING_TIME + "\n");
            writer.write("roundTime:" + ROUND_LENGTH + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("- Configurations saved");
    }
} // end of ServerModel class
