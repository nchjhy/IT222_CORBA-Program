package Server_Java.model;

/**
 * Utility class to store and retrieve the server IP address.
 */
public class IPAdd {
    private static String serverIP;

    /**
     * Retrieves the server IP address.
     *
     * @return The server IP address.
     */
    public static String getServerIP() {
        return serverIP;
    }

    /**
     * Sets the server IP address.
     *
     * @param ipAdd The IP address to set.
     */
    public static void setServerIP(String ipAdd) {
        serverIP = ipAdd;
    }
} // end of IPAdd class