package Server_Java.model;

import BoggledApp.GameRound;
import BoggledApp.Player;
import Server_Java.database.DatabaseManager;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * Represents a game session in the Boggled application.
 * Manages the game rounds, players, word entries, points, and winners.
 */
public class GameSession {
    private final int gsID; // Represents the unique identifier for the game session.
    private GameRound round = null, nextRound = new GameRound(); // Tracks the current round and the next round to be played in the game session.
    private final List<Player> players = new ArrayList<>(); // Stores the list of players participating in the game session.
    private final HashMap<Integer, HashSet<String>> wordEntryMap = new LinkedHashMap<>(); // Maps each player's ID to a set of words they have submitted during the game session.
    private final HashMap<Integer, List<Integer>> pointsMap = new LinkedHashMap<>(); // Maps each player's ID to a list of points they have earned in each round of the game session.
    private final HashMap<Integer, Integer> winCountMap = new LinkedHashMap<>(); // Tracks the number of wins for each player in the game session.
    private String roundWinner = "None"; // Stores the username of the winner of the current round. Initialized to "None" indicating no winner yet.
    private String gameWinner = "None"; // Stores the username of the winner of the entire game session. Initialized to "None" indicating no winner yet.
    private int roundTime; // Tracks the remaining time for the current round.
    private int roundNumber; // Tracks the number of rounds played in the game session.
    private int totalSubmissions; // Tracks the total number of word submissions received for the current round.
    private boolean roundEvaluationDone = false; // Indicates whether the evaluation of the current round is complete.
    private final AtomicBoolean startNextRound = new AtomicBoolean(false); // Atomic boolean flag used to signal the start of the next round.
    private final CountDownLatch submitLatch; // Used to synchronize the submission of words from all players before proceeding to the next round.

    /**
     * Constructs a new GameSession with the specified game session ID.
     *
     * @param gsID The unique identifier for the game session.
     */
    public GameSession(int gsID) {
        this.gsID = gsID;

        // Initialize the CountDownLatch to synchronize word submissions.
        submitLatch = new CountDownLatch(1);

        // Initialize the total number of word submissions and round number.
        totalSubmissions = 0;
        roundNumber = 0;
    }

    /**
     * Starts the game session by initializing the first round and managing round transitions.
     * This method starts a new thread to handle the game flow asynchronously.
     */
    public void startGame() {
        // Generate the first round.
        nextRound = generateRound();

        // Start a new thread to manage the game flow.
        Thread startGameThread = new Thread(() -> {
            while (true) {
                // Check if it's time to start the next round.
                if (startNextRound.get()) {
                    synchronized (this) {
                        // Set the round time to the predefined length.
                        roundTime = ServerModel.ROUND_LENGTH;

                        try {
                            // Wait for a brief period before starting the round.
                            Thread.sleep(5000);
                            System.out.println("- STARTING ROUND");

                            // Decrease the round time countdown until it reaches -1.
                            while (roundTime != -1) {
                                roundTime--;
                                Thread.sleep(1000);
                            }

                            // Evaluate the round results when the time is up.
                            evaluateRound();

                            // Reset the flag for starting the next round.
                            startNextRound.set(false);

                            // Generate the next round.
                            nextRound = generateRound();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
        // Set the new thread as a daemon to ensure it doesn't prevent the program from exiting.
        startGameThread.setDaemon(true);
        // Start the game management thread.
        startGameThread.start();
    }

    /**
     * Adds a player to the game session.
     * Initializes data structures for tracking player points, word entries, and win count.
     *
     * @param playerID The ID of the player to be added.
     */
    public void addPlayer(int playerID) {
        // Retrieve player information from the database based on the playerID.
        Player player = DatabaseManager.getPlayer(playerID);

        // Add the player to the list of players in the game session.
        players.add(player);

        // Initialize a list to store points earned by the player.
        pointsMap.put(playerID, new ArrayList<>());

        // Initialize a set to store word entries submitted by the player.
        wordEntryMap.put(playerID, new HashSet<>());

        // Initialize the win count for the player to 0.
        winCountMap.put(playerID, 0);
    }

    /**
     * Adds a word entry submitted by a player to the game session.
     *
     * @param playerID The ID of the player submitting the word.
     * @param word     The word submitted by the player.
     */
    public void addWordEntry(int playerID, String word) {
        // Convert the word to lowercase and add it to the word entry set of the corresponding player.
        wordEntryMap.get(playerID).add(word.toLowerCase());
    } // end of addWordEntry

    /**
     * Retrieves the next round of the game and prepares for the start of the round.
     * This method waits until all players have submitted their entries for the current round.
     *
     * @return The next round of the game.
     */
    public GameRound getNextRound() {
        try {
            // Increment the total submissions counter and check if all players have submitted their entries.
            synchronized (this) {
                totalSubmissions++;

                // Set the flag to start the next round.
                if (totalSubmissions == players.size()) {
                    startNextRound.set(true);

                    // Reset the submission count and round evaluation status.
                    totalSubmissions = 0;
                    roundEvaluationDone = false;

                    // Signal that the current round has been completed.
                    submitLatch.countDown();
                }
            }

            // Wait until the current round is evaluated and the next round is ready to start.
            submitLatch.await();

            // Retrieve the next round and return it.
            round = nextRound;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return round;
    } // end of getNextRound

    /**
     * Removes a player from the game session.
     * This method removes the player's data, including word entries, win count, and points.
     *
     * @param playerID The ID of the player to be removed.
     */
    public void removePlayer(int playerID) {
        // Remove the player from the list of players if their ID matches.
        players.removeIf(player -> player.playerID == playerID);

        // Remove the player's word entries, win count, and points.
        wordEntryMap.remove(playerID);
        winCountMap.remove(playerID);
        pointsMap.remove(playerID);
    }

    /**
     * Evaluates the current round.
     * This method computes the points earned by each player, determines the round winner,
     * checks for the game winner, updates game and player details in the database,
     * and marks the round evaluation as done.
     */
    public void evaluateRound() {
        // Compute points earned by each player based on their word entries.
        computePoints();

        // Determine the round winner.
        roundWinner = evaluateRoundWinner();

        // Check if there is a game winner.
        gameWinner = evaluateGameWinner();

        // Update game and player details if there is a game winner.
        if (!gameWinner.equals("None")) {
            // Update total points for each player.
            players.forEach(player -> player.totalPoints += pointsMap.get(player.playerID)
                    .stream()
                    .mapToInt(Integer::intValue)
                    .sum());

            // Find the ID of the winner player.
            int winnerPlayerID = players.stream().filter(player -> player.username.equals(gameWinner))
                    .mapToInt(player -> player.playerID)
                    .findFirst().orElse(-1);

            // save game details
            DatabaseManager.updateGameSession(gsID, winnerPlayerID);

            // update player points
            DatabaseManager.updatePlayerPoints(players);

            // add 1 win to the winner
            DatabaseManager.updateWin(winnerPlayerID);

        }

        // Mark round evaluation as done.
        roundEvaluationDone = true;

        System.out.println("\n- FINISHED EVALUATING CURRENT ROUND");
    } // end of evaluateRound

    /**
     * Computes the points earned by each player based on their word entries.
     * Points are calculated based on the uniqueness of words submitted by the player.
     */
    private void computePoints() {
        // Create a list of all word entries submitted by all players.
        List<String> combinedWordEntries = new ArrayList<>();

        // Combine all submitted words from all players into a single list
        for (HashSet<String> entry : wordEntryMap.values()) {
            combinedWordEntries.addAll(entry);
        }

        // Iterate through each player
        for (Player player : players) {
            int points = 0; // Initialize points for the current player

            // Retrieve the set of words submitted by the current player
            HashSet<String> wordSet = wordEntryMap.get(player.playerID);

            // Iterate through each word submitted by the player
            for (String word : wordSet) {
                // Check if the word appears only once among all players' submissions
                if (Collections.frequency(combinedWordEntries, word) == 1) {
                    // If the word appears only once, add its length to the player's points
                    points += word.length();
                }
            }
            // Add the calculated points to the points map for the current player
            pointsMap.get(player.playerID).add(points);
        }
    } // end of computePoints

    /**
     * Evaluates the winner of the current round.
     * This method determines the player with the highest points as the round winner.
     * If there is a tie in points, no round winner is declared.
     * If there is a round winner, their username is returned, and their win count is updated.
     * If no player wins the round, "None" is returned.
     *
     * @return The username of the round winner, "None" if no winner.
     */
    private String evaluateRoundWinner() {
        String name = "None"; // Default round winner name

        // Variable to track the highest points earned and
        // Player ID of the round winner
        int highestPoints = 0, roundWinnerPlayerID = 0;

        // Iterate through each player's points
        for (Map.Entry<Integer, List<Integer>> entry : pointsMap.entrySet()) {
            List<Integer> pointsList = entry.getValue();
            int lastIndex = pointsList.size() - 1;

            int playerPoints = pointsList.get(lastIndex);

            // Compare the player's points with the current highest points
            if (playerPoints > highestPoints) {
                highestPoints = playerPoints;
                roundWinnerPlayerID = entry.getKey();
            } else if (highestPoints == playerPoints) {
                // If there is a tie, set the winner to "None"
                name = "None";
                roundWinnerPlayerID = 0;
            }
        }

        // If there is a clear winner, update their win count and return their username
        if (roundWinnerPlayerID != 0) {
            for (Player player : players) {
                name = player.username; // Set the round winner's username
                // Increment the win count for the round winner
                winCountMap.compute(roundWinnerPlayerID, (key, value) -> value + 1);
                break;
            }
        }
        return name;
    } // end of evaluateRoundWinner

    /**
     * Determines the winner of the game based on the number of rounds won by each player.
     * If a player has won 3 rounds, they are declared the game winner.
     *
     * @return The username of the game winner if one exists, otherwise returns "None".
     */
    private String evaluateGameWinner() {
        return players.stream() // converts the list of players into a stream
                .filter(player -> winCountMap.containsKey(player.playerID) && winCountMap.get(player.playerID) == 3) // filters the stream to include only those players who have a win count of exactly 3. It checks if the player's ID exists in the winCountMap and if the corresponding win count is equal to 3
                .map(player -> player.username) // maps each player to their username. After filtering, we are left with a stream of usernames of players who have exactly 3 wins
                .findFirst() // returns the first element of the stream, which is the username of the first player who has exactly 3 wins
                .orElse("None"); // provides a default value ("None") to return if the optional is empty, meaning no player with 3 wins was found
    } // end of evaluateGameWinner

    /**
     * Generates a new game round.
     * Increments the round number, clears the word entries for all players,
     * and creates a new GameRound object with the current game session ID,
     * player data, character set, and current round number.
     *
     * @return The newly generated GameRound object.
     */
    private GameRound generateRound() {
        roundNumber++;

        // Clear word entries for all players
        wordEntryMap.values().forEach(HashSet::clear);

        // Create a new GameRound object with necessary data
        GameRound gameRound = new GameRound();
        gameRound.gsID = gsID;
        gameRound.players = getPlayerData();
        gameRound.characters = generateCharacterSet();
        gameRound.currentRoundNumber = roundNumber;

        return gameRound;
    } // end of generateRound

    /**
     * Generates a random character set for the game round.
     * The character set consists of 7 randomly chosen vowels and 13 randomly chosen consonants.
     *
     * @return The generated character set as a string.
     *
     * @implNote This method uses Math.random() to generate random indices for selecting characters from the vowels and consonants strings.
     */
    private String generateCharacterSet() {
        String vowels = "aeiou";
        String consonants = "bcdfghjklmnpqrstvwxyz";
        List<Character> characterSet = new ArrayList<>();

        // Add 7 random vowels to the character set
        for (int i = 0; i < 7; i++) {
            characterSet.add(vowels.charAt((int) (Math.random() * vowels.length())));
        }

        // Add 13 random consonants to the character set
        for (int i = 0; i < 13; i++) {
            characterSet.add(consonants.charAt((int) (Math.random() * consonants.length())));
        }

        // Convert the character set to a string and return
        return characterSet.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());
    } // end of generateCharacterSet

    /**
     * Retrieves player data including username, win count, and total points.
     * The data is sorted based on win count in descending order.
     *
     * @return An array containing player data in the format: "username-winCount-totalPoints".
     */
    public String[] getPlayerData() {
        // Temporary list to store player data strings
        List<String> temp = new ArrayList<>();

        // Iterate through each player
        for (Player player : players) {
            // Retrieve the win count for the current player
            int winCount = winCountMap.get(player.playerID);

            // Retrieve the points list for the current player
            List<Integer> pointsList = pointsMap.get(player.playerID);
            // Check if the points list is empty
            if (pointsList.isEmpty()) {
                // Add player data to the temporary list with total points as 0
                temp.add(player.username + "-" + winCount + "-" + 0);
            } else {
                // Calculate total points for the current player
                int totalPoints = 0;

                for (int roundPoints : pointsList) {
                    totalPoints += roundPoints;
                }

                // Add player data to the temporary list with calculated total points
                temp.add(player.username + "-" + winCount + "-" + totalPoints);
            }
        }

        // Sort the player data based on win count in descending order
        temp.sort((a, b) -> {
            int winCountA = Integer.parseInt(a.split("-")[1]);
            int winCountB = Integer.parseInt(b.split("-")[1]);
            return Integer.compare(winCountB, winCountA);
        });

        // Convert the list of player data to an array and return
        return temp.toArray(new String[0]);
    } // end of getPlayerData

    /**
     * Checks if the evaluation of the current round is done.
     *
     * @return True if the evaluation of the current round is done, otherwise false.
     */
    public boolean roundEvaluationDone() {
        return roundEvaluationDone;
    }

    /**
     * Gets the number of players in the game session.
     *
     * @return The number of players in the game session.
     */
    public int getPlayerCount() {
        return players.size();
    }

    /**
     * Gets the remaining time for the current round.
     *
     * @return The remaining time for the current round.
     */
    public int getRoundTime() {
        return roundTime;
    }

    /**
     * Checks if the game session is valid, i.e., if there are more than one player in the session.
     *
     * @return True if the game session is valid, otherwise false.
     */
    public boolean isValid() {
        return players.size() > 1;
    }

    /**
     * Gets the game session ID.
     *
     * @return The game session ID.
     */
    public int getGsID() {
        return gsID;
    }

    /**
     * Gets the username of the winner of the current round.
     *
     * @return The username of the winner of the current round.
     */
    public String getRoundWinner() {
        return roundWinner;
    }

    /**
     * Gets the username of the winner of the game session.
     *
     * @return The username of the winner of the game session.
     */
    public String getGameWinner() {
        return gameWinner;
    }

    /**
     * Gets the character set used for the current round.
     *
     * @return The character set used for the current round.
     */
    public String getCharacterSet() {
        return round.characters;
    }
}
