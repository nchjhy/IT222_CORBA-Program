package Server_Java.model;

import Server_Java.database.DatabaseManager;

import java.util.Arrays;
import java.util.List;
/**
 * This class provides methods to retrieve data for the admin interface
 * from the {@link DatabaseManager}.
 */
public class AdminModel {
    /**
     * Constructs an {@code AdminModel} object.
     */
    public AdminModel(){}

    /**
     * Retrieves the leaderboard entries.
     *
     * @return a list of leaderboard entries
     * @see DatabaseManager#getLeaderboardEntries()
     */
    public List<String> getLeaderboard() {
        return DatabaseManager.getLeaderboardEntries();
    }

    /**
     * Retrieves the list of players.
     *
     * @return a list of players
     * @see DatabaseManager#getPlayerList()
     */
    public List<String> getPlayers() {
        return DatabaseManager.getPlayerList();
    }

    /**
     * Retrieves the leaderboard entries that match the specified keyword.
     *
     * @param keyword the keyword to match
     * @return a list of leaderboard entries
     * @see DatabaseManager#getLeaderboardEntries(String)
     */
    public List<String> getLeaderboard(String keyword) {
        return DatabaseManager.getLeaderboardEntries(keyword);
    }

    /**
     * Retrieves the list of players that match the specified keyword.
     *
     * @param keyword the keyword to match
     * @return a list of players
     * @see DatabaseManager#getPlayerList(String)
     */
    public List<String> getPlayers(String keyword) {
        return DatabaseManager.getPlayerList(keyword);
    }
}
